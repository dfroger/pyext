import mymath
print(mymath.sqrt(2))
print(mymath.square(2))
