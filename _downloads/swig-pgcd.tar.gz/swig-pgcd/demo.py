import pgcd

print(pgcd.pgcd(10,5))
print(pgcd.pgcd(7,42))
print(pgcd.pgcd(0,42))
print(pgcd.pgcd(-8,64))
