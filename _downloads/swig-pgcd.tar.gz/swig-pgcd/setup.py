#!/usr/bin/env python
from distutils.core import setup, Extension

pgcd = Extension(
        '_pgcd',
        sources = ['pgcd.i','pgcd.c',],
        )

setup (name = 'pgcd',
       ext_modules = [pgcd,],
       py_modules = ['pgcd'],
       )
