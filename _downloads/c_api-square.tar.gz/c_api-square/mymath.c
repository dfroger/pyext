#include <Python.h>
#include "math.h"

double square(double number) {
    return number*number;
};

static PyObject *
mymath_square(PyObject *self, PyObject *args)
{
    double number;
    double number_square;

    if (!PyArg_ParseTuple(args,"d", &number))
        return NULL;
    number_square = square(number);

    return PyFloat_FromDouble(number_square);
}

static PyMethodDef MymathMethods[] = {

    {"square", mymath_square, METH_VARARGS,
        "Compute square of a number"},

    {NULL, NULL, 0, NULL} /*Sentinel*/
};

static struct PyModuleDef mymath = {
    PyModuleDef_HEAD_INIT,
    "mymath", /* name of the module */
    "Mathematics module", /* module documentation */
    -1,
    MymathMethods
};
     
PyMODINIT_FUNC
PyInit_mymath(void)
{
    return PyModule_Create(&mymath);
}
