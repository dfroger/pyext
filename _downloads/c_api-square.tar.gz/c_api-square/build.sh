gcc `python3-config --cflags` -fPIC -c mymath.c
gcc `python3-config --ldflags` -shared mymath.o -o mymath.so
