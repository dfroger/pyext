import mymath
print(mymath.square(2))
