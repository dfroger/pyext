import numpy as np
import myvector

a = np.arange(10, dtype='d')
v = myvector.Vector()
v.set_data(a)
v.display()
