#!/usr/bin/env python

import unittest

from factorize_integer import factorize_integer

class TestFactorizeInteger(unittest.TestCase):
    """Test computation of all dividers of an integer

    Note that 'factorize_integer' raise an error if the product of the
    dividers is not equal to the number"""

    def test_normal(self):
        factorize_integer(2*5)

    def test_one(self):
        factorize_integer(1)

    def test_two(self):
        factorize_integer(2)

    def test_multiple(self):
        factorize_integer(2*2*5*5)

    def test_prime(self):
        factorize_integer(17)

if __name__ == '__main__':
    unittest.main()
