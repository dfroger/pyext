for number in \
    688846502588399 \
    18014398777917439 \
    32361122672259149 \
    59604644783353249 \
    99194853094755497 \
    489133282872437279
do
    echo $number ...
    time python factorize_integer.py $number
    echo
done

