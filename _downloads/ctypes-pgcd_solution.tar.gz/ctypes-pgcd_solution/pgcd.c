#include "pgcd.h"

int pgcd(int a, int b) {
    if ( a==0 || b==0 )
        return 0;
    int x;
    if (b>a) {
        x = b;
        b = a;
        a = x;
    }
    while ( (x=a%b) != 0 ) {
        a = b;
        b = x;
    }
    return b;
};

