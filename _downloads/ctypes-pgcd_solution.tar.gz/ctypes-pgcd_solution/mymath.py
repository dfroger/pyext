import ctypes

mymath = ctypes.cdll.LoadLibrary("./libmymath.so")
pgcd = mymath.pgcd

pgcd.argtypes = [ctypes.c_int, ctypes.c_int]
pgcd.restype = ctypes.c_int
