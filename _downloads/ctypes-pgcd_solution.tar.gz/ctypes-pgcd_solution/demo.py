import mymath

print(mymath.pgcd(10,5))
print(mymath.pgcd(7,42))
print(mymath.pgcd(0,42))
print(mymath.pgcd(-8,64))
