#include "util.hxx"

void set_matrix_value(SomeMatrix* A)
{
    double *data = A->get_data();
    for (IndexType irow=0 ; irow<A->get_nrow() ; irow++) {
    for (IndexType icol=0 ; icol<A->get_ncol() ; icol++) {
        *(data++) = irow*10 + icol;
    }}
}

void set_element_to_zero(SomeMatrix* A, IndexType irow, IndexType icol)
{
    double* data = A->get_data();
    IndexType ncol = A->get_ncol();
    data[irow*ncol + icol] = 0.;
}
