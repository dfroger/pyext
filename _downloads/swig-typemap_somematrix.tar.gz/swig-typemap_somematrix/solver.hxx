#ifndef SOLVER_HXX
#define SOLVER_HXX

#include "somematrix.hxx"

typedef unsigned int IndexType;

class Solver {
    public:
        Solver(IndexType);
        ~Solver();
        SomeMatrix* get_A(){return m_A;};
        void display();
    private:
        IndexType m_n;
        SomeMatrix* m_A;
};

#endif
