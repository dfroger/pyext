import solver as slv
n = 4
solver = slv.Solver(n)
A = solver.get_A()
slv.set_matrix_value(A)
slv.set_element_to_zero(A,2,3)
solver.display()
print(A)
A.display()
print(A.get_data())
