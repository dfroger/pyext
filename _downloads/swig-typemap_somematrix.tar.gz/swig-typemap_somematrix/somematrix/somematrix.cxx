#include "somematrix.hxx"

SomeMatrix::SomeMatrix(const unsigned int nrow, const unsigned int ncol):
    m_nrow(nrow),
    m_ncol(ncol)
{
    m_nrow = nrow;
    m_ncol = ncol;
    m_data = new double[nrow*ncol];
}

SomeMatrix::~SomeMatrix()
{
    delete[] m_data;
}

void SomeMatrix::display()
{
    for (unsigned int irow=0 ; irow<m_nrow ; irow++) {
        cout << "row " << irow << ":"  << endl;
        for (unsigned int icol=0 ; icol<m_ncol ; icol++) {
            cout << m_data[irow*m_ncol + icol] << " ";
        }
        cout << endl;
    }
}

double SomeMatrix::compute_something() 
{
    return 3.1;
}
