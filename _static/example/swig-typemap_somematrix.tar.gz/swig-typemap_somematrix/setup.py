#!/usr/bin/env python
from distutils.core import setup, Extension

import numpy

solver = Extension(
        '_solver',
        sources = ['solver.i','solver.cxx',
                   'util.cxx','somematrix/somematrix.cxx'],
        include_dirs = ['somematrix', numpy.get_include(),],
        swig_opts = ['-c++'],
        )

setup (name = 'solver',
       ext_modules = [solver,],
       py_modules = ['solver'],
       )
