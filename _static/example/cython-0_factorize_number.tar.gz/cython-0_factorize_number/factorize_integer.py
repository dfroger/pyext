#!/usr/bin/env python
import sys
import operator
from functools import reduce

from find_divider import find_divider

def factorize_integer(number):
    """Compute and check dividers of an integer"""
    if number < 2:
        return [number,]

    dividers = []
    rest = number

    while rest != 1:
        divider = find_divider(rest)
        rest /= divider
        dividers.append(divider)

    if not reduce(operator.mul, dividers) == number:
        raise RuntimeError("Product of %r is not equal to %r" 
            % (dividers,number))

    return dividers

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Usage: %s NUMBER' % sys.argv[0])
        sys.exit(1)
    number = int( sys.argv[1] )
    dividers = factorize_integer(number)
    print('dividers are', dividers)
