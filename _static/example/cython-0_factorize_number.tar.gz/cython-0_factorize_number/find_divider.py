from math import sqrt

def find_divider(number):
    """Compute the first divider (greatest than 1) of number"""
    number_sqrt = int(sqrt(number)+1)
    for divider in range(2, number_sqrt):
        if number % divider == 0:
            return divider
    else:
        return number;

