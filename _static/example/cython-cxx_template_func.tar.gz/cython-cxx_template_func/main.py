import numpy as np

import mymath

a = np.arange(4, dtype='d')
print(mymath.average(a))

a = np.array([10,10,20,20])
print(mymath.average(a))
