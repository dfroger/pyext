#ifndef AVERAGE_HXX
#define AVERAGE_HXX

template<class T>
T average(T *numbers_list, unsigned int size)
{
    T average = 0;
    unsigned int i;
    for (i = 0 ; i < size ; i++)
        average += numbers_list[i];
    return average / size;
}

#endif
