#ifndef PAIR_HXX_INCLUDED
#define PAIR_HXX_INCLUDED

#include <iostream>

using namespace std;

class MyPair {
    public:
        MyPair(double value0, double value1) {
            m_values[0] = value0;
            m_values[1] = value1;
        }
        void display() {
            cout << "(" << m_values[0] << ", " << m_values[1] << ")" << endl;
        }
    private:
        double m_values[2];
};

#endif
