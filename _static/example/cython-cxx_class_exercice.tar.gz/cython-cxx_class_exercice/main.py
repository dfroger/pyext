import pair

p = pair.MyPair(10.1, 20.2)
p.display()
