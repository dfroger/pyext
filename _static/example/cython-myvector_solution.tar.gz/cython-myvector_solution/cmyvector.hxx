#ifndef VECTOR_HXX
#define VECTOR_HXX

#include <iostream>
using namespace std;

class Vector {
    public:
        Vector(){};
        void set_data(double* data){m_data = data;};
        void set_size(unsigned int size){m_size = size;};
        void display();
    private:
        double* m_data;
        unsigned int m_size;
};

#endif
