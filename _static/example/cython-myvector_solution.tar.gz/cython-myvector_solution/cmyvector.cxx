#include "cmyvector.hxx"

void Vector::display()
{
    for (unsigned int i=0 ; i<m_size ; i++) {
        cout << m_data[i] << endl;
    }
}
