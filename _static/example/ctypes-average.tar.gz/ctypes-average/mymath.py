import ctypes

import numpy as np

c_mymath = ctypes.cdll.LoadLibrary("./libmymath.so")
c_average = c_mymath.average

def average(numbers_list):
    arr = np.asarray(numbers_list, dtype=np.float64)
    arr_type = np.ctypeslib.ndpointer(dtype=np.float64, ndim=1)

    c_average.argtypes = [arr_type, ctypes.c_uint, ]
    c_average.restype = ctypes.c_double

    return c_average(arr, len(arr))
