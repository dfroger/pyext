import mymath
import numpy as np

l = [300,30,3]
a = np.array([300,30,3])

print( mymath.average(l) )
print( mymath.average(a) )
