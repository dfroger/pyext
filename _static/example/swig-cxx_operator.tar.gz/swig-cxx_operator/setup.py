from distutils.core import Extension, setup

mycomplex = Extension(
    '_mycomplex',
    sources = ['mycomplex.i', 'mycomplex.cxx'],
    swig_opts = ['-c++'],
)

setup(
    name = 'mycomplex',
    ext_modules = [mycomplex],
    py_modules = ['mycomplex']
)
