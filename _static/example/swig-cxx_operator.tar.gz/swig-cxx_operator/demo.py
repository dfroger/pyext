from mycomplex import Complex
a = Complex(1,2)
b = Complex(3,4)
c = a + b
c += a
print c.re(), c.im()
