import numpy as np
import vector
a = [1,2,3.5]
a = np.array([1,2,3],dtype='i')
a = np.array([1.,2.5,4.1])

vi = vector.VectorInt()
vi.initialize(a)
vi.display()

#vf = vector.VectorFloat()
#vf.initialize(a)
#vf.display()

#vd = vector.VectorDouble()
#vd.initialize(a)
#vd.display()
