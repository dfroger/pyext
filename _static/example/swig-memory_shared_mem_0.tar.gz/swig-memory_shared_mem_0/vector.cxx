#include "vector.hxx"

Vector::Vector():
    m_data(NULL),
    m_size(-1)
{
}

Vector::~Vector()
{
    if (m_data) delete m_data;

}

void Vector::initialize(double* data, unsigned int size)
{
    m_data = data;
    m_size = size;
}

void Vector::initialize_cpy(double* data, unsigned int size)
{
    m_data = new double[size];
    m_size = size;
    for (unsigned i=0 ; i<size ; i++)
        m_data[i] = data[i];
}

void Vector::display()
{
    for (unsigned int i=0 ; i<m_size ; i++)
        cout << m_data[i] << endl;
}
