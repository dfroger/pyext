#!/usr/bin/env python
from distutils.core import setup, Extension

vector = Extension(
        '_vector',
        sources = ['vector.i',],
        swig_opts = ['-c++'],
        )

setup (name = 'vector',
       ext_modules = [vector,],
       py_modules = ['vector'],
       )

