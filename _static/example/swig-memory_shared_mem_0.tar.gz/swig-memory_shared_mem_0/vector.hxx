#ifndef VECTOR_HXX_INCLUDED
#define VECTOR_HXX_INCLUDED

#include <iostream>

using namespace std;

class Vector
{
    public:
        Vector();
        ~Vector();
        void initialize(double* data, unsigned int size);
        void initialize_cpy(double* data, unsigned int size);
        void display();
    private:
        double* m_data;
        unsigned int m_size;
};

#endif
