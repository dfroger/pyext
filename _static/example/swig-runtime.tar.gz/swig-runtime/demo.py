import solver as slv
n = 4
solver = slv.Solver(n)
slv.set_matrix_value( solver.get_A() )
slv.set_element_to_zero(solver.get_A(),2,3)
solver.display()
