#ifndef SOME_MATRIX_HXX
#define SOME_MATRIX_HXX

#include <iostream>

using namespace std;

class SomeMatrix {
    public:
        SomeMatrix(const unsigned int nrow,
                   const unsigned int ncol);
        ~SomeMatrix();
        double* get_data() {return m_data;};
        unsigned int get_nrow() {return m_nrow;};
        unsigned int get_ncol() {return m_ncol;};
        void display();
        double compute_something();
    private:
        unsigned int m_nrow, m_ncol;
        double *m_data;
};

#endif
