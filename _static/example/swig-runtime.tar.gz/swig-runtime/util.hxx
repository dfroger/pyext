#ifndef UTIL_HXX
#define UTIL_HXX

#include "somematrix.hxx"
#include "solver.hxx"

void set_matrix_value(SomeMatrix* A);

void set_element_to_zero(SomeMatrix* A,
                         IndexType irow,
                         IndexType icol);

#endif
