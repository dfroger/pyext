#include "solver.hxx"
#include "util.hxx"

int main()
{
    const unsigned int n=4;
    Solver solver(n);
    set_matrix_value( solver.get_A() );
    set_element_to_zero(solver.get_A(), 2, 2);
    solver.display();
}
