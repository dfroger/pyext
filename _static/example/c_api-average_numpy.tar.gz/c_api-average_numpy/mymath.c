#include <Python.h>
#include <numpy/arrayobject.h>
#include <math.h>

double square(double number) {
    return number*number;
};

static PyObject *
mymath_square(PyObject *self, PyObject *args)
{
    double number;
    double number_square;

    if (!PyArg_ParseTuple(args,"d", &number))
        return NULL;
    number_square = square(number);

    return PyFloat_FromDouble(number_square);
}

double c_sqrt(double number) {
    return sqrt(number);
};

static PyObject *
mymath_sqrt(PyObject *self, PyObject *args)
{
    double number;
    double number_sqrt;

    if (!PyArg_ParseTuple(args,"d",&number))
        return NULL;

    if (number < 0.) {
        PyErr_SetString(PyExc_ValueError,"number must be positive");
        return NULL;
    }

    number_sqrt = sqrt(number);

    return PyFloat_FromDouble(number_sqrt);
}

double average(double *numbers_list, unsigned int size)
{
    double average = 0;
    unsigned int i;
    for (i = 0 ; i < size ; i++)
        average += numbers_list[i];
    return average / size;
}

static PyObject *
mymath_average(PyObject *self, PyObject *args)
{
    PyObject* input;
    double a;

    if (!PyArg_ParseTuple(args,"O",&input))
        return NULL;

    if (!PyArray_Check(input)) {
        PyErr_SetString(PyExc_TypeError,"input must be a numpy array");
        return NULL;
    }

    PyArrayObject * nparray = (PyArrayObject *) input;

    if (nparray->nd != 1) {
        PyErr_SetString(PyExc_TypeError,"number of dimensions must be 1");
        return NULL;
    }

    a = average(nparray->data, nparray->dimensions[0]);

    return PyFloat_FromDouble(a);
}

static PyMethodDef MymathMethods[] = {
    {"square", mymath_square, METH_VARARGS, "Compute square of a number"},
    {"sqrt", mymath_sqrt, METH_VARARGS, "Compute root square of a number"},
    {"average", mymath_average, METH_VARARGS, "Compute average of list of numbers"},
    {NULL, NULL, 0, NULL} /*Sentinel*/
};

static struct PyModuleDef mymath = {
    PyModuleDef_HEAD_INIT,
    "mymath", /* name of the module */
    "Mathematics module", /* module documentation */
    -1,
    MymathMethods
};
     
PyMODINIT_FUNC
PyInit_mymath(void)
{
    import_array();
    return PyModule_Create(&mymath);
}
