import numpy as np
import mymath

a = np.array([3.,30,300.])
print(mymath.average(a))
