import numpy as np
import mymath

eq = mymath.almost_equal

a = np.array( [1.,2.,3.] )
b = np.array( [1.,2.,3.] )
eps = 1.E-08
print( eq(a,b,eps) )

a[1] += 1.E-03
print( eq(a,b,eps) )
print( eq(a,b,1.E-01) )
