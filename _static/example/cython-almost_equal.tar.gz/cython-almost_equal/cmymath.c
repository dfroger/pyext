#include "cmymath.h"

int
almost_equal(double *array1, double* array2,
             unsigned int n, double eps)
{
    unsigned int i;
    double diff;
    for (i=0 ; i<n ; i++) {
        diff = fabs( array1[i]-array2[i] );
        if ( diff > eps )
            return i;
    }
    return -1;
}
