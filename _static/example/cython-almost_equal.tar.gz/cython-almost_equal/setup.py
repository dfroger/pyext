#!/usr/bin/env python
from distutils.core import setup, Extension
from Cython.Build import cythonize

mymath = Extension(
    'mymath',
    sources = ['mymath.pyx','cmymath.c',],
)

setup(
    name = 'mymath',
    ext_modules = cythonize(mymath),
)
