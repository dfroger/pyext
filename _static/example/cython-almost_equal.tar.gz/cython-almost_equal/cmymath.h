#ifndef MYMATH_H
#define MYMATH_H

#include <math.h>

int almost_equal(double* array1, double* array2,
                 unsigned int n, double eps);

#endif
