#ifndef COMPLEX_HXX_INCLUDED
#define COMPLEX_HXX_INCLUDED

class Complex {
    public:
        Complex(double r=0, double i=0): m_r(r), m_i(i) {};
        Complex(const Complex &c): m_r(c.m_r), m_i(c.m_i) {};

        Complex operator+=(const Complex &c);
        Complex operator+(const Complex &c) const;

        double re() const {return m_r;};
        double im() const {return m_i;};
    private:
        double m_r, m_i;
};

#endif
