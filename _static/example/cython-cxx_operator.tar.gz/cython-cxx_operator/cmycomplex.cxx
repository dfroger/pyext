#include "cmycomplex.hxx"

Complex Complex::operator+=(const Complex &c) {
    this->m_r += c.m_r;
    this->m_i += c.m_i;
    return *this;
}

Complex Complex::operator+(const Complex &c) const {
    return Complex(re()+c.re(), im()+c.im());
}
