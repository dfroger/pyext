from distutils.core import Extension, setup
from Cython.Build import cythonize

mycomplex = Extension(
    'mycomplex',
    sources = ['mycomplex.pyx', 'cmycomplex.cxx'],
    language = 'c++',
)

setup(
    name = 'mycomplex',
    ext_modules = cythonize(mycomplex),
)
