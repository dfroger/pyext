from mycomplex import Complex
a = Complex(1,2)
b = Complex(3,4)
print()
c = a + b
#print(c.re(), c.im())
