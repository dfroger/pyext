from distutils.core import Extension, setup
from Cython.Build import cythonize

ext = Extension('demo', sources = ['demo.pyx'])

setup(
    name = 'demo',
    ext_modules = cythonize(ext),
)
