import numpy as np

import demo

demo.example()

a = np.arange(10, dtype='d')

print(demo.average(a))
