import mymath

print(mymath.average([3.,30.,300]))
#print mymath.average([3.,30.,"str"])
#print mymath.average("str")
