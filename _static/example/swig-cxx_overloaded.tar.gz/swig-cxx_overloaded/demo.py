import foo

print foo.foo(1)
print foo.foo(1.)
print foo.foo(1.,2.)
