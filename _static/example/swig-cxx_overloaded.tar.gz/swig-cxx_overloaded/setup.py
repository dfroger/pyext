from distutils.core import setup, Extension

foo = Extension(
    "_foo",
    sources = ['foo.i',],
    swig_opts = ['-c++'],
)

setup(
    name = 'foo',
    ext_modules = [foo,],
    py_modules = ['foo',],
)

