#ifndef FOO_INCLUDED_HXX
#define FOO_INCLUDED_HXX

int foo(int a) {return a+1;};
double foo(double a) {return a+10;};
double foo(double a, double b) {return a+b;};

#endif
