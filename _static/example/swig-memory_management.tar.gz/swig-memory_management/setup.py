#!/usr/bin/env python2.7
from distutils.core import setup, Extension

demo = Extension(
        '_demo',
        sources = ['demo.i',],
        swig_opts=["-c++",],
        )

setup (name = 'demo',
       ext_modules = [demo,],
       py_modules = ['demo'],
       )

