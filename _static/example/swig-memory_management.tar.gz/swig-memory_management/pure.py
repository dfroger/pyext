class Foo:

    def __init__(self,x):
        self.m_bar = Bar(x)

    def bar(self):
        return self.m_bar

class Bar:

    def __init__(self,x):
        self.m_x = x

    def x(self):
        return self.m_x

bar = Foo(123).bar()
print bar.x()
