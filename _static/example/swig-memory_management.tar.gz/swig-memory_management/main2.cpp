#include "foo.hpp"
#include <iostream>
using namespace std;

Bar& get_bar() {
    Foo foo(123);
    Bar& bar = foo.bar()
}

int main() {
    Bar& bar = get_bar()
    cout << bar().x() << endl;
}

