from demo import Foo

bar = Foo(123).bar()
print bar.x()
