#ifndef BAR_HPP_INCLUDED
#define BAR_HPP_INCLUDED

#include <iostream>

using namespace std;

class Bar {
    int m_x;
public:
    Bar() { cout << "Bar: default constructor" << endl; }
    ~Bar() { cout << "Bar: destructor" << endl; }
    Bar(int x): m_x(x) { cout << "Bar: constructor (int x)" << endl; }
    int x() const { cout << "Bar: getter x" << endl; return m_x; }
};

#endif
