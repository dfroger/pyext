#ifndef FOO_HPP_INCLUDED
#define FOO_HPP_INCLUDED

#include "bar.hpp"
#include <iostream>

using namespace std;

class Foo {
    Bar m_bar;
public:
    Foo() { cout << "Foo: default constructor" << endl; }; 
    Foo(int x): m_bar(x) { cout << "Foo: constructor (int x)" << endl; }
    ~Foo() { cout << "Foo: destructor" << endl; }
    Bar& bar() { cout << "Foo: getter bar" << endl; return m_bar; }
};

#endif
