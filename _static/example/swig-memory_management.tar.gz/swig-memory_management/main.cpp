#include "foo.hpp"
#include <iostream>
using namespace std;

int main() {
    cout << Foo(123).bar().x() << endl;
}
