import numpy as np
import myvector

a = np.arange(10)
v = myvector.Vector()
v.set_data_size(a)
v.display()
