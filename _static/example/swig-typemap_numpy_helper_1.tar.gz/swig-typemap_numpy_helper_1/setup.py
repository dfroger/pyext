#!/usr/bin/env python
from distutils.core import setup, Extension

myvector = Extension(
        '_myvector',
        sources = ['myvector.i','myvector.cxx',],
        swig_opts = ['-c++'],
        )

setup (name = 'myvector',
       ext_modules = [myvector,],
       py_modules = ['myvector'],
       )


