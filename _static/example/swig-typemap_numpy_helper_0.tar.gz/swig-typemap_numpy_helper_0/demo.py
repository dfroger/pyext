import numpy as np
import mymath

a = [1,2,3]
b = [1,2,3]
eps = 1.E-08

print mymath.almost_equal(a,b,eps)

a = np.array( [1.,2.+1.E-03,3.] )
b = np.array( [1.,2.,3.] )

print mymath.almost_equal(a,b,eps)
print mymath.almost_equal(a,b,1.E-01)
