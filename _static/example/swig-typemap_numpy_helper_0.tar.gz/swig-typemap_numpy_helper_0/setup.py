#!/usr/bin/env python
from distutils.core import setup, Extension

mymath = Extension(
        '_mymath',
        sources = ['mymath.i','mymath.c',],
        )

setup (name = 'mymath',
       ext_modules = [mymath,],
       py_modules = ['mymath'],
       )

