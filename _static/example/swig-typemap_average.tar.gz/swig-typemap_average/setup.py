#!/usr/bin/env python
from distutils.core import setup, Extension

import numpy

mymath = Extension(
        '_mymath',
        sources = ['mymath.i','mymath.c',],
        include_dirs = [numpy.get_include(),],
        )

setup (name = 'mymath',
       ext_modules = [mymath,],
       py_modules = ['mymath'],
       )
