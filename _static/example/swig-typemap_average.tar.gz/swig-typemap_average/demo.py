import mymath

print( mymath.average([1,2,3]) )
