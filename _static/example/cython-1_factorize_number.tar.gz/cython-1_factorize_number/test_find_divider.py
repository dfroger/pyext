#!/usr/bin/env python

import unittest

from find_divider import find_divider

class TestFindDivider(unittest.TestCase):
    """Test computation of first divider of an integer"""

    def test_normal(self):
        divider = find_divider(35)
        self.assertEqual(divider,5)

    def test_one(self):
        divider = find_divider(1)
        self.assertEqual(divider,1)

    def test_two(self):
        divider = find_divider(2)
        self.assertEqual(divider,2)

    def test_prime(self):
        divider  = find_divider(17)
        self.assertEqual(divider,17)

if __name__ == '__main__':
    unittest.main()
