#include "cfind_divider.h"
#include <math.h>

/* Compute the first divider (greatest than 1) of number */
ullong find_divider(ullong number)
{
    ullong divider;
    ullong number_sqrt = (ullong) sqrt(number)+1;

    for (divider = 2 ; divider < number_sqrt ; divider++) {
        if (number % divider == 0)
            return divider;
    }

    return number;
}
