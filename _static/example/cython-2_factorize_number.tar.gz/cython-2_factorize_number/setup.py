#!/usr/bin/env python
from distutils.core import Extension, setup
from Cython.Build import cythonize

ext = Extension(
    'find_divider',
    sources=[
        'find_divider.pyx',
        'cfind_divider.c',
    ],
)

setup(
    name = 'find_divider',
    ext_modules = cythonize(ext),
)
