#ifndef FIND_DIVIDER_H_INCLUDED
#define FIND_DIVIDER_H_INCLUDED

typedef unsigned long long ullong;

ullong find_divider(ullong number);

#endif
