#!/usr/bin/env python
from find_divider import find_divider
from math import *
import operator
from functools import reduce

def find_dividers(number):
    """Iterate over dividers of an integer"""
    while number != 1:
        divider = find_divider(number)
        number /= divider
        yield divider

def factorize_integer(number,verbose=False):
    """Compute and check dividers of an integer"""
    if number < 2:
        return [number,]
    dividers = [divider for divider in find_dividers(number)]
    if not reduce(operator.mul, dividers) == number:
        raise RuntimeError("Product of %r is not equal to %r" 
            % (dividers,number))
    return dividers
