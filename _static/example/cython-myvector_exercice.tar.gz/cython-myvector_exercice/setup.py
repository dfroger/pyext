#!/usr/bin/env python
from distutils.core import setup, Extension
from Cython.Build import cythonize

myvector = Extension(
    'myvector',
    sources = ['myvector.pyx','cmyvector.cxx',],
    language = 'c++',
)

setup(
    name = 'myvector',
    ext_modules = cythonize(myvector),
)
