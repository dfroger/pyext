import mymath

print mymath.average_double([1,2,3])
