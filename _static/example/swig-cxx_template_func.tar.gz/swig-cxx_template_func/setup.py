#!/usr/bin/env python
from distutils.core import setup, Extension

mymath = Extension(
        '_mymath',
        sources = ['mymath.i',],
        swig_opts = ['-c++'],
        )

setup (name = 'mymath',
       ext_modules = [mymath,],
       py_modules = ['mymath'],
       )

