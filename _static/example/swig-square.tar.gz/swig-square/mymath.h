#ifndef MYMATH_H
#define MYMATH_H

#include <math.h>

double square(const double number);

#endif
