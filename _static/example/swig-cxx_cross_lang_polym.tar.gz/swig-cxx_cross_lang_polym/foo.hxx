#ifndef FOO_HXX_INCLUDED
#define FOO_HXX_INCLUDED

class Foo {
    public:
        Foo(){};
        virtual void bar(){};
        void baz(){bar();};
};

#endif
