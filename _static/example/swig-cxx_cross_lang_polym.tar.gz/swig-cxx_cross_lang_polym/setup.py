from distutils.core import Extension, setup

foo = Extension(
    "_foo",
    sources = ["foo.i"],
    swig_opts = ["-c++"],
)

setup(
    name = 'foo',
    ext_modules = [foo,],
    py_modules = ['foo.py'],
)
