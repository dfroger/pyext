import foo

class MyFoo(foo.Foo):
    def __init__(self):
        foo.Foo.__init__(self)
    def bar(self):
        print "bar"

f = MyFoo()
f.baz()
