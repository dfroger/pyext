#!/usr/bin/env python
from distutils.core import setup, Extension

mymath = Extension(
    'mymath',
    sources = ['mymath.c',],
    )

setup (name = 'mymath',
    ext_modules = [mymath,],
    py_modules = ['mymath'],
    )
