import mymath

print(mymath.pgcd(18,42))
