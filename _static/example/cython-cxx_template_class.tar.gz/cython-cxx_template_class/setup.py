from distutils.core import setup, Extension
from Cython.Build import cythonize

pair = Extension(
    "pair",
    sources = ['pair.pyx',],
    language = 'c++',
)

setup(
    name = 'pair',
    ext_modules = cythonize(pair),
)
