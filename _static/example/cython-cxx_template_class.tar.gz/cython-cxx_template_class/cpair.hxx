#ifndef PAIR_HXX_INCLUDED
#define PAIR_HXX_INCLUDED

#include <iostream>

using namespace std;

template <class T>
class MyPair {
    public:
        MyPair(T value0, T value1) {
            m_values[0] = value0;
            m_values[1] = value1;
        }
        void display() {
            cout << "(" << m_values[0] << ", " << m_values[1] << ")" << endl;
        }
    private:
        T m_values[2];
};

#endif
