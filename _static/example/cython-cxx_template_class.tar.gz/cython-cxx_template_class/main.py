import pair

pair.example()
