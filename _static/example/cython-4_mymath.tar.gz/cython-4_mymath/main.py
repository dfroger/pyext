import fraction
import mymath

nume, denu = '18','42'
simple_nume, simple_denu = fraction.simplify(nume,denu)

print(nume, ' ', simple_nume)
print("--", '=', '-')
print(denu, ' ', simple_denu)

print(mymath.pgcd(nume, denu))
