from distutils.core import setup, Extension

pair = Extension(
    "_pair",
    sources = ['pair.i',],
    swig_opts = ['-c++',],
)

setup(
    name = 'pair',
    ext_modules = [pair,],
    py_modules = ['pair'],
)
