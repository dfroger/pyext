import pair

p = pair.MyPairInt(1,2)
p.display()
