#!/usr/bin/env python
from distutils.core import setup, Extension

solver = Extension(
        '_solver',
        sources = ['solver.i','solver.cxx',
                   'util.cxx','somematrix/somematrix.cxx'],
        include_dirs = ['somematrix'],
        swig_opts = ['-c++'],
        )

setup (name = 'solver',
       ext_modules = [solver,],
       py_modules = ['solver'],
       )
