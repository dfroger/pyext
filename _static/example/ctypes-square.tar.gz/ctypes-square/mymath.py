import ctypes

mymath = ctypes.cdll.LoadLibrary("./libmymath.so")
square = mymath.square

square.argtypes = [ctypes.c_double, ]
square.restype = ctypes.c_double
