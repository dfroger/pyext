import mymath

print(mymath.square(10))
