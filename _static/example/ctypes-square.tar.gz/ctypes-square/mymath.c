#include "mymath.h"

double square(const double number) {
    return number*number;
};
