#ifndef PGCD_H
#define PGCD_H

int pgcd(int a, int b);

#endif
