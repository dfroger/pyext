#!/usr/bin/env python
from distutils.core import setup, Extension
from Cython.Build import cythonize

solver = Extension(
        'linalg',
        sources = [
            'linalg.pyx',
            'solver.cxx',
            'util.cxx',
            'somematrix/somematrix.cxx'
        ],
        include_dirs = ['somematrix'],
        language = 'c++',
        )

setup(
    name = 'linalg',
    ext_modules = cythonize([solver,]),
)
