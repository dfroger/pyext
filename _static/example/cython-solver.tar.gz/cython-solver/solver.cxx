#include "solver.hxx"

Solver::Solver(IndexType n):
    m_n(n)
{
    m_A = new SomeMatrix(n,n);
}

Solver::~Solver()
{
    delete m_A;
}

void Solver::display()
{
    m_A->display();
}
