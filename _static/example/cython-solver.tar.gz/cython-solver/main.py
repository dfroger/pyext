import linalg

n = 4

print('Using example function:')
linalg.example(4)

print('\nUsing Solver class:')
solver = linalg.Solver(n)
solver.set_matrix_value()
solver.set_element_to_zero(2,3)
solver.display()
