import mypair

p = mypair.MyPair(4, 5)
p.second = 7
print(p)
