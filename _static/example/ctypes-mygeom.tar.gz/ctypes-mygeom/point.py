import ctypes

c_geom = ctypes.cdll.LoadLibrary("./libgeom.so")

class CPoint(ctypes.Structure):
    _fields_ = [("x", ctypes.c_double),
                ("y", ctypes.c_double)]

class Point:
    def __init__(self, x, y):
        point_new = c_geom.point_new
        point_new.argtypes = [ctypes.c_double, ctypes.c_double]
        point_new.restype = ctypes.POINTER(CPoint)
        self._c_point = point_new(x,y)
    def display(self):
        display = c_geom.display
        display.argtypes = [ctypes.POINTER(CPoint)]
        display.restype = None
        display(self._c_point)
    def distance(self, other):
        distance = c_geom.distance
        distance.argtypes = [ctypes.POINTER(CPoint), 
                             ctypes.POINTER(CPoint)]
        distance.restype = ctypes.c_double
        return distance(self._c_point, other._c_point)
    def __del__(self):
        point_destroy = c_geom.point_destroy
        point_destroy.argtypes = [ctypes.POINTER(CPoint)]
        point_destroy.restype = None
        point_destroy(self._c_point)
