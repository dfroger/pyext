#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "point.h"

Point*
point_new(double x, double y)
{
    Point* point = (Point*) malloc(sizeof(Point));
    point->x = x;
    point->y = y;
    return point;
}

void
point_destroy(Point* const point)
{
    free(point);
}

void
display(Point const * const point)
{
    printf("<Point(%.2f %.2f)>\n", point->x, point->y);
}

double
distance(Point const * const A, Point const * const B)
{
    double xx = pow(B->x - A->x, 2);
    double yy = pow(B->y - A->y, 2);
    return sqrt(xx + yy);
}
