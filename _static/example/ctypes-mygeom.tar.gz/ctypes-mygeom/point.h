#ifndef POINT_H_INCLUDED
#define POINT_H_INCLUDED

typedef struct point {
    double x;
    double y;
} Point;

Point*
point_new(double x, double y);

void
point_destroy(Point* const point);

void
display(Point const * const point);

double
distance(Point const * const A, Point const * const B);

#endif
