from point import Point

A = Point(1.0, 3.0)
B = Point(2.0, 4.0)
A.display()
print(A.distance(B))
