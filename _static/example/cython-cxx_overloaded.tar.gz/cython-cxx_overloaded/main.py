import foo

print(foo.foo(1))
print(foo.foo(1.))
print(foo.foo(1.,2.))

try:
    print(foo.foo("hello"))
except TypeError:
    print("TypeError catched with string argument")

try:
    print(foo.foo(1.,2.,3.))
except TypeError:
    print("TypeError catched with 3 arguments")
