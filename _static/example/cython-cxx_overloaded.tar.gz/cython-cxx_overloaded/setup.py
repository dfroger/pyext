from distutils.core import setup, Extension
from Cython.Build import cythonize

foo = Extension(
    "foo",
    sources = ['foo.pyx',],
    language = 'c++',
)

setup(
    name = 'foo',
    ext_modules = cythonize(foo),
)

