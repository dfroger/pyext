#include "mymatrix.hxx"

MyMatrix::MyMatrix(unsigned int nrow, unsigned int ncol)
{
    m_data = new double[nrow*ncol];
    m_nrow = nrow;
    m_ncol = ncol;
    double *p = m_data;
    for (int i=0 ; i<nrow*ncol ; i++)
        *(p++) = 0.;
}

MyMatrix::~MyMatrix()
{
    //if (m_data) delete[] m_data;
    //m_data = NULL;
    delete[] m_data;
}
