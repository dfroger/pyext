#include "solver.hxx"

Solver::~Solver(){
    delete m_A;
}

void Solver::display()
{
    unsigned int nrow = m_A->nrow();
    unsigned int ncol = m_A->ncol();
    for (unsigned int irow=0 ; irow<nrow ; irow++) {
        cout << "row " << irow << ":"  << endl;
        for (unsigned int icol=0 ; icol<ncol ; icol++) {
            cout << m_A->data()[irow*ncol + icol] << " ";
        }
        cout << endl;
    }
}
