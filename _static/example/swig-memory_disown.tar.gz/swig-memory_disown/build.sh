CF="-pthread -fno-strict-aliasing -DNDEBUG -fwrapv -O2 -Wall -Wstrict-prototypes"
swig -python -c++ -o solver_wrap.cpp solver.i
g++ -g -O1 -fPIC -I/usr/include/python2.7_d -c solver_wrap.cpp -o solver_wrap.o
g++ -g -O1 -fPIC -I/usr/include/python2.7_d -c mymatrix.cxx -o mymatrix.o
g++ -g -O1 -fPIC -I/usr/include/python2.7_d -c solver.cxx -o solver.o
g++ -g -shared -Wl,-O1 -Wl,-Bsymbolic-functions,-z,relro,-g solver_wrap.o mymatrix.o solver.o -o /home/david/repo/dfswig/source/example/disown/_solver.so
