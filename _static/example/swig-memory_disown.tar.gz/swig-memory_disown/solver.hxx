#ifndef SOLVER_HXX_INCLUDED
#define SOLVER_HXX_INCLUDED

#include <cstddef>
#include <iostream>
#include "mymatrix.hxx"

using namespace std;

class Solver {
    public:
        Solver():m_A(NULL){};
        ~Solver();
        void set_A(MyMatrix* A){m_A = A;};
        void display();
    private:
        MyMatrix* m_A;
};

#endif
