#include "solver.hxx"

int main()
{
    MyMatrix* A = new MyMatrix(5,5);
    Solver solver;
    solver.set_A(A);
    delete[] A->data();
}
