#ifndef MY_MATRIX_HXX_INCLUDED
#define MY_MATRIX_HXX_INCLUDED

#include <cstddef>

class MyMatrix {
    public:
        MyMatrix():m_data(NULL),m_ncol(-1),m_nrow(-1){};
        MyMatrix(unsigned int nrow, unsigned int ncol);
        ~MyMatrix();
        unsigned int nrow(){return m_nrow;};
        unsigned int ncol(){return m_ncol;};
        double* data(){return m_data;};
    private:
        double* m_data;
        unsigned int m_ncol, m_nrow;

};

#endif
