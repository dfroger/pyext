import solver

def create_solver():
    A = solver.MyMatrix(5,5)
    #A.this.disown()
    s = solver.Solver()
    s.set_A(A)
    return s

s = create_solver()
