from distutils.core import Extension, setup

solver = Extension(
    '_solver',
    sources = ['solver.i','mymatrix.cxx','solver.cxx',],
    include_dirs = ['/usr/include/python2.7_d'],
    swig_opts = ['-c++'],
)

setup(
    name = 'solver',
    ext_modules = [solver,],
    py_modules = ['solver',],
)
