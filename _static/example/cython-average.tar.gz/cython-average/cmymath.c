double
average(double *numbers_list,
        unsigned int size)
{
    double average = 0;
    unsigned int i;
    for (i = 0 ; i < size ; i++)
        average += numbers_list[i];
    return average / size;
}

