import numpy as np
import mymath

a = np.arange(4, dtype='d')
print(mymath.average(a))
