#ifndef AVERAGE_H
#define AVERAGE_H

double
average(double *numbers_list,
        unsigned int size);

#endif
